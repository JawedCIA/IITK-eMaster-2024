#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <calc.h>


double calculate(char *buf){

  /*************************************************************
   Implement the expression evaluation functionality which
   will be invoked by the server whenever required.
  *************************************************************/

  double operands[20];
  char op[20];
  int oprnInd = 0;
  double result = 0.0;

  // implement expression evaluation functionality here



  return(result);
}

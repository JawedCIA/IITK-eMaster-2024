#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main(int argc, char **argv){
  /* we invoke driver program as follows:
     ./task2_driver <user1_content> <user1_store> <user2_content> <user2_store>

     sample content for user 1 and 2 are available as chat-1.txt and chat-2.txt file.

     use task2_user binary to exec user program as child process.
  */


  return 0;
}
